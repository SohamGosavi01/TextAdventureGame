﻿class Enemy:
    def __init__(self, name, hp, damage):
        self.name = name
        self.hp = hp
        self.damage = damage
 
    def is_alive(self):
        return self.hp > 0

class Crocodile(Enemy):
    def __init__(self):
        super().__init__(name="Crocodile", hp=10, damage=2)
 
class Elephant(Enemy):
    def __init__(self):
        super().__init__(name="Elephant", hp=30, damage=15)

class Monkey(Enemy):
    def __init__(self):
        super().__init__(name="Monkey", hp=20, damage=10)

class Lion(Enemy):
    def __init__(self):
        super().__init__(name="Lion", hp=25, damage=15)