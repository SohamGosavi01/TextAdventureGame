﻿# Base class for all items
class Item():
    # __init__ is the contructor method
    def __init__(self, name, description, value):
        self.name = name   # attribute of the Item class and any subclasses
        self.description = description # attribute of the Item class and any subclasses
        self.value = value # attribute of the Item class and any subclasses
    
    # __str__ method is used to print the object
    def __str__(self):
        return "{}\n=====\n{}\nValue: {}\n".format(self.name, self.description, self.value)

# Extend the Items class

class Weapon(Item):
    def __init__(self, name, description, value, damage):
        self.damage = damage
        super().__init__(name, description, value)
 
    def __str__(self):
        return "{}\n=====\n{}\nValue: {}\nDamage: {}".format(self.name, self.description, self.value, self.damage)
 
class BigJaw(Weapon):
    def __init__(self):
        super().__init__(name="BigJaw",
                         description="Super Big Jaw of the Animal",
                         value=5,
                         damage=15)
 
class ElephantTrunk(Weapon):
    def __init__(self):
        super().__init__(name="ElephantTrunk",
                         description="Trunk attack of big elephant",
                         value=10,
                         damage=5)
class MonkeyTail(Weapon):
    def __init__(self):
        super().__init__(name="MonkeyTail",
                         description="A Splash with the tail Lord Hanuman",
                         value=2,
                         damage=10)
class LionRoar(Weapon):
    def __init__(self):
        super().__init__(name="LionRoar",
                         description="A Deadly roar of a deadly lion",
                         value=3,
                         damage=2)
class AnimalBramhastra(Weapon):
    def __init__(self):
        super().__init__(name="AnimalBramhastra",
                         description="A weapon to kill everyone",
                         value=6,
                         damage=10)