﻿import items, enemies, actions, world
 
class MapTile:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    def intro_text(self):
        raise NotImplementedError()
 
    def modify_player(self, player):
        raise NotImplementedError()

    def adjacent_moves(self):
        """Returns all move actions for adjacent tiles."""
        moves = []
        if world.tile_exists(self.x + 1, self.y):
            moves.append(actions.MoveEast())
        if world.tile_exists(self.x - 1, self.y):
            moves.append(actions.MoveWest())
        if world.tile_exists(self.x, self.y - 1):
            moves.append(actions.MoveNorth())
        if world.tile_exists(self.x, self.y + 1):
            moves.append(actions.MoveSouth())
        return moves
 
    def available_actions(self):
        """Returns all of the available actions in this room."""
        moves = self.adjacent_moves()
        moves.append(actions.ViewInventory())
 
        return moves


class GothamCityEntrance(MapTile):
    # override the intro_text method in the superclass
    def intro_text(self):
        return """
        Its the fight between the jungle animals
        """
 
    def modify_player(self, player):
        #Room has no action on player
        pass

class LootRoom(MapTile):
    def __init__(self, x, y, item):
        self.item = item
        super().__init__(x, y)
 
    def add_loot(self, player):
        player.inventory.append(self.item)
 
    def modify_player(self, player):
        self.add_loot(player)

class EnemyRoom(MapTile):
    def __init__(self, x, y, enemy):
        self.enemy = enemy
        super().__init__(x, y)
 
    def modify_player(self, the_player):
        if self.enemy.is_alive():
            the_player.hp = the_player.hp - self.enemy.damage
            print("Enemy does {} damage. You have {} HP remaining.".format(self.enemy.damage, the_player.hp))

    def available_actions(self):
        if self.enemy.is_alive():
            return [actions.Flee(tile=self), actions.Attack(enemy=self.enemy), actions.Equip()]
        else:
            return self.adjacent_moves()

class GameLand(MapTile):
    def intro_text(self):
        return """
        GameLand.One should decide where to go
        """
 
    def modify_player(self, player):
        #Room has no action on player
        pass
 
class Crocodile(EnemyRoom):
    def __init__(self, x, y):
        super().__init__(x, y, enemies.Crocodile())
 
    def intro_text(self):
        if self.enemy.is_alive():
            return """
            Crocodile 
            """
        else:
            return """
            Crocodile is defeated
            """


class Elephant(EnemyRoom):
    def __init__(self, x, y):
        super().__init__(x, y, enemies.Elephant())

    def intro_text(self):
        if self.enemy.is_alive():
            return """
             Elephant trunk attack!
             """
        else:
            return """
             Elephant has been defeated.
             """
class Monkey(EnemyRoom):
    def __init__(self, x, y):
        super().__init__(x, y, enemies.Monkey())

    def intro_text(self):
        if self.enemy.is_alive():
            return """
             Monkey has attacked you with the tail!
             """
        else:
            return """
             Monkey could not succeed
             """

class Lion(EnemyRoom):
    def __init__(self, x, y):
        super().__init__(x, y, enemies.Lion())

    def intro_text(self):
        if self.enemy.is_alive():
            return """
             Lion uses his roar!
             """
        else:
            return """
             Lion is defeated!
             """

class FindBatarang(LootRoom):
    def __init__(self, x, y):
        super().__init__(x, y, items.Batarang())
 
    def intro_text(self):
        return """
        Time to realise and fight back
        """


class Brahmastra(Room):
    def __init__(self, x, y):
        super().__init__(x, y, items.Room())

    def intro_text(self):
        return """
     Wepon of the great animal found
        """
class Defeater(MapTile):
  
    def modify_player(self, player):
        player.victory = True